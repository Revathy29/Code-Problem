package test.code.checkTemp;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class temperatureAvg {

	public static void main(String[] args) {
	
		String inputData = "1,10000,40\n" + 
				"1,10002,45\n" + 
				"1,11015,50\n" + 
				"2,10005,42\n" + 
				"2,11051,45\n" + 
				"2,12064,42\n" + 
				"2,13161,42\n" ;
		
		System.out.println("**One Second Duration**\n");
		findAvgTemp(inputData,1000);
		System.out.println("\n**Two Second Duration**\n");
		findAvgTemp(inputData,2000);
	}
	
	private static void findAvgTemp(String temperatureData, int interval) {
	
		Map<Integer, String> tempMap = new HashMap<>();
		int secs, keyValue;
		String strTemp;
		
		String[] singleLine = temperatureData.split("\\n");
		for(int i=0;i<singleLine.length;i++) {
			
			String[] tempData = singleLine[i].split(",");
			secs = Integer.parseInt(tempData[1])/interval;
			keyValue = interval*secs;
			if(tempMap.get(keyValue)==null ){
				tempMap.put(keyValue, tempData[2]);
			}
				
			else{	
				strTemp = tempMap.get(keyValue);
				tempMap.put(keyValue, strTemp+","+tempData[2]);
			}
		}
		
		for(Map.Entry<Integer, String> printMap : tempMap.entrySet()) {
		 
			Integer temperature= printMap.getKey();
			String list1= printMap.getValue();
			String[] tempList = list1.split(",");
		
			int counter = 0;
			float sum1 = 0;
			for(int j=0;j<tempList.length;j++) {
				sum1 = sum1+ Float.parseFloat(tempList[j]);
				counter++;
			}

			System.out.println("Average Temperature @"+temperature+" is "+sum1/counter);

		}
	}
}

