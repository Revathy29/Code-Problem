package test.code.checkTemp;

import java.util.HashMap;
import java.util.Map;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import test.code.checkTemp.temperatureAvg;


public class temperatureAvgTest  extends TestCase
{
	private String inputData;
	temperatureAvg tempAvg = new temperatureAvg();
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public temperatureAvgTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( temperatureAvgTest.class );
    }

    @Override
    protected void setUp() {
    	System.out.println("Setting up the input Data");
    	inputData = "1,10000,40\n" + 
				"1,10002,45\n" + 
				"1,11015,50\n" + 
				"2,10005,42\n" + 
				"2,11051,45\n" + 
				"2,12064,42\n" + 
				"2,13161,42\n" ;
    	
    }
    
    public void tearDown() {
    	
    }

    public void testtemperatureAvg()
    {
    	Map<Integer, String> actualMap = new HashMap<>(); 
    	Map<Integer, String> expectedMap = new HashMap<>();
    	expectedMap.put(10000, "40,45,42");
    	expectedMap.put(11000, "50,45");
    	//test.code.checkTemp.temperatureAvg.findAvgTemp(inputData,1000);
        assertEquals(actualMap,expectedMap);
    }
}