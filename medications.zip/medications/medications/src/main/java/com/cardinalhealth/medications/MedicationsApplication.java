package com.cardinalhealth.medications;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicationsApplication.class, args);
	}
}
