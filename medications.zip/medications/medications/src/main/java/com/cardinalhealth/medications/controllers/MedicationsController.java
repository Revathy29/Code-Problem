package com.cardinalhealth.medications.controllers;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cardinalhealth.medications.models.ErrorData;
import com.cardinalhealth.medications.models.Medications;
import com.cardinalhealth.medications.models.Prescriber;

@RestController
@RequestMapping("/medications")
public class MedicationsController {
	
	private static final String PRESCRIBER_NAME_IS_REQUIRED = "Prescriber name is required";
	private static final String CONDITION_IS_REQUIRED = "Condition is required";
	private static final String DIRECTIONS_FOR_USE_IS_REQUIRED = "Directions for use is required";
	private static final String NAME_IS_REQUIRED = "Name is required";
	private static final String PRESCRIBER_IS_REQUIRED = "Prescriber is required";
	private final Logger logger = LoggerFactory.getLogger(MedicationsController.class);
	private Map<UUID,Medications> medicationsMap;
	public MedicationsController() {
		medicationsMap = new HashMap<>();
		addMedications(new Medications("ASPIRIN TAB 81MG","Take one tablet when needed","Headache",new Prescriber("John Smith")));
		addMedications(new Medications("PETOPROL SUC TAB 50MG ER","Take one tablet twice each day","Heart Health",new Prescriber("John Smith")));
		addMedications(new Medications("NAPROXEN TAB 500MG","Take two tablets when needed","Back Pain",new Prescriber("Self")));
		addMedications(new Medications("PANTOPRAZOLE TAB 40MG","Take one spoonful by mouth daily","Heartburn",new Prescriber("Suzan Jones")));
		addMedications(new Medications("TAMSULOSIN CAP 0.4MG","Take one capsule at bedtime","Blood",new Prescriber("Self")));
		addMedications(new Medications("PROAIR HFA AER","Inhale 2 puffs daily","Asthma",new Prescriber("Mike Sims")));
		addMedications(new Medications("CLOPIDOGREL TAB 75MG","Take one table 4 times a day","Cancer",new Prescriber("John Smith")));
		addMedications(new Medications("ADEMPAS TAB 0.5MG","TAKE 1/2 TABLET BY MOUTH DAILY IN THE MORNING","REALLY BAD SLEEPINESS",new Prescriber("Jack Jones")));
	}
	
	//Method to load the map
    private void addMedications(Medications medication) {
        medicationsMap.put(medication.getId(), medication);
        logger.info("Medications Map after Addition" + medicationsMap.values());
        
    }
    
    //To return the list of all Medications
	@GetMapping
	public Collection<Medications> list(){
		return medicationsMap.values();
	}

	//To add new Medications and handle error data
	@PostMapping(consumes= "application/json", produces="application/json")
	@ResponseStatus(HttpStatus.OK)
	public void create(@RequestBody Medications medication) {
		logger.info("Adding new Medication");
		
		boolean isErrorData = false;
		final ErrorData errorData = new ErrorData();
		
		if(medication.getName() == null || medication.getDirectionsForUse() == null || medication.getCondition() == null
				|| medication.getPrescriber() == null)
			isErrorData = true;
		
		if(medication.getName() == null) 
			errorData.setName(NAME_IS_REQUIRED);
		else
			errorData.setName(medication.getName());
		
		if(medication.getDirectionsForUse() == null) 
			errorData.setDirectionsForUse(DIRECTIONS_FOR_USE_IS_REQUIRED);
		else
			errorData.setDirectionsForUse(medication.getDirectionsForUse());
		
		if(medication.getCondition() == null) 
			errorData.setCondition(CONDITION_IS_REQUIRED);
		else
			errorData.setCondition(medication.getCondition());
			
		if(medication.getPrescriber() == null) {
			errorData.setPrescriber(PRESCRIBER_IS_REQUIRED);
			errorData.setPrescriberName(PRESCRIBER_NAME_IS_REQUIRED);
		}
		
		else {
				errorData.setPrescriber("");
				if(medication.getPrescriber().getName() == null) {
					isErrorData = true;
					errorData.setPrescriberName(PRESCRIBER_NAME_IS_REQUIRED);
			}
				else
					errorData.setPrescriberName(medication.getPrescriber().getName());
		}
		if(!isErrorData)
			medicationsMap.put(medication.getId(), medication);
		else
			logger.info("Error in Data -> " + errorData);
				
	}
	
	//To search for a medication based on the name
	@GetMapping(value="/search")
	public Collection<Medications> get(@RequestParam("name") String name) {
		
		Map<UUID,Medications> searchMedication = new HashMap<>();
		Set<Map.Entry<UUID, Medications>> entries = medicationsMap.entrySet();
		for(Map.Entry<UUID, Medications> medication : entries) {
			Medications medic = medication.getValue();
			if(medic.getName().toLowerCase().contains(name.toLowerCase())) {
				logger.info("Search Results --> " + medic.getName());
				searchMedication.put(medic.getId(), medic);
			}
		}
		if(searchMedication.isEmpty()) {
			logger.info("No medication matched the search result");
		}
		return searchMedication.values();
	}
	
	//To delete a medication based on id
	@DeleteMapping(value="/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Collection<Medications> delete(@PathVariable UUID id) {
		if(medicationsMap.get(id) != null)
			medicationsMap.remove(id);
		else
			logger.info("DELETE not Successful -> requested element is not in the list");
		return medicationsMap.values();
	}
	
	
}
