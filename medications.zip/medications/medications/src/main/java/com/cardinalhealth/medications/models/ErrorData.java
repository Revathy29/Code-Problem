package com.cardinalhealth.medications.models;

import java.util.UUID;

public class ErrorData {
	
	private String name;
	private String directionsForUse;
    private String condition;
    private String prescriber;
	private String prescriberName;
	
	
		
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDirectionsForUse() {
		return directionsForUse;
	}
	public void setDirectionsForUse(String directionsForUse) {
		this.directionsForUse = directionsForUse;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getPrescriber() {
		return prescriber;
	}
	public void setPrescriber(String prescriber) {
		this.prescriber = prescriber;
	}
	public String getPrescriberName() {
		return prescriberName;
	}
	public void setPrescriberName(String prescriberName) {
		this.prescriberName = prescriberName;
	}

	 @Override
	    public String toString() {
	        return "ErrorData {" +
	                " Name='" + name + '\'' +
	                ", directionsForUse='" + directionsForUse + '\'' +
	                ", condition='" + condition + '\'' +
	                ", prescriber='{" + prescriber + '\'' +	  
	                ", prescriber.name='" + prescriberName + '\'' +
	                '}';
	    }
}
