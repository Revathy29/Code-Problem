package com.cardinalhealth.medications.models;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Medications {

	private  final UUID id;
	private String name;
	private String directionsForUse;
    private String condition;
    private Prescriber prescriber;
    
    @JsonCreator
	public Medications(@JsonProperty("name") String name, @JsonProperty("directionsForUse") String directionsForUse, @JsonProperty("condition") String condition,@JsonProperty("prescriber") Prescriber prescriber) {
    	this.id = UUID.randomUUID();
		this.name = name;
		this.directionsForUse = directionsForUse;
		this.condition = condition;
		this.prescriber = prescriber;
	}

	
	public UUID getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getDirectionsForUse() {
		return directionsForUse;
	}
	public String getCondition() {
		return condition;
	}
	public Prescriber getPrescriber() {
		return prescriber;
	}

	 @Override
	    public String toString() {
	        return "Medication {" +
	                " Name='" + name + '\'' +
	                ", directionsForUse='" + directionsForUse + '\'' +
	                ", condition='" + condition + '\'' +
	                ", prescriber='" + prescriber + '\'' +	                
	                '}';
	    }

}
