package com.cardinalhealth.medications.models;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Prescriber {

	
    private UUID id;
    private String name;
    
    @JsonCreator
	public Prescriber(@JsonProperty("name") String name) {
   		this.id = UUID.randomUUID();
		this.name = name;
	}
 
    
	public UUID getId() {
		return id;
	}
	public String getName() {
		return name;
	}

	@Override
    public String toString() {
        return "{" +
                " Name='" + name + '\'' +
                '}';
    }
}
