package com.cardinalhealth.medications.controllers;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.Collection;
import java.util.UUID;

import org.junit.Before;
import org.junit.Test;

import com.cardinalhealth.medications.models.Medications;
import com.cardinalhealth.medications.models.Prescriber;


public class MedicationsControllerTest {

	private MedicationsController medicationsController;
	private Collection<Medications> medications;
	
	@Before
	public void setUp() {
		medicationsController = new MedicationsController();
		medications = medicationsController.list();
	}
	
    @Test
    public void testGetAllMedications() {
    	
        assertEquals(medications.size(),8);
    }
    
    @Test
    public void testGetMedicationsByName() {
        
        Collection<Medications> searchResult = medicationsController.get("TAB");
        assertThat(medications.containsAll(searchResult));
        assertEquals(searchResult.size(),6);
           
    }
    
    @Test
    public void testGetMedicationsByNameWhenNoResultsReturned() {
        
        Collection<Medications> searchResult = medicationsController.get("XXXYY");
        assertThat(medications.containsAll(searchResult));
        assertEquals(searchResult.size(),0);
           
    }
    
    @Test
      public void testDeleteMedicationsById() {
        
    	Medications medElement = medications.iterator().next();
    	Collection<Medications> searchResultBefore = medicationsController.get(medElement.getName());
    	assertThat(medications.containsAll(searchResultBefore));
        assertEquals(searchResultBefore.size(),1);
        
        medicationsController.delete(medElement.getId());
     	
        Collection<Medications> searchResultAfter = medicationsController.get(medElement.getName());
     	assertEquals(searchResultAfter.size(),0);
        assertEquals(medications.size(),7);
           
    }
 
    
    @Test
      public void testDeleteMedicationsByIdWhenIdNotPresent() {
        
    	medicationsController.delete(UUID.randomUUID());
     	
        Collection<Medications> searchResultAfter = medicationsController.get("xyz");
     	assertEquals(searchResultAfter.size(),0);
        assertEquals(medications.size(),8);
           
    }
    
    @Test
    public void testAddMedication() {
    
    Medications medication = new Medications("TRADJENTA TAB 5MG","SWALLOW PILL ONCE IT IS IN YOUR MOUTH.","ARTHRITIS",new Prescriber("Dr. Phil"));
  	medicationsController.create(medication);
  	Collection<Medications> afterAdd = medicationsController.get(medication.getName());
 	assertEquals(afterAdd.size(),1);
    assertEquals(medications.size(),9);     
  }
    
    @Test
    public void testAddMedicationForErrorScenario() {
    
    Medications medication = new Medications(null,"SWALLOW PILL ONCE IT IS IN YOUR MOUTH.",null,new Prescriber("Dr. Phil"));
    medicationsController.create(medication);
  	Collection<Medications> afterAdd = medicationsController.get(medication.getDirectionsForUse());
 	assertEquals(afterAdd.size(),0);
    assertEquals(medications.size(),8);     
  }
 
    
}
